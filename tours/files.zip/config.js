/* ============================================================
   Travelfy Tours — Configuración de Supabase (un solo lugar)
   Pega aquí tu URL y anon key UNA sola vez.
   Todas las páginas (index, tours y las de detalle) las leen de aquí.
   NUNCA pongas aquí la service_role key: solo la anon public.
   ============================================================ */
window.TRAVELFY_CONFIG = {
  SUPABASE_URL:  "https://TU-PROYECTO.supabase.co",
  SUPABASE_ANON: "TU_ANON_KEY"
};
